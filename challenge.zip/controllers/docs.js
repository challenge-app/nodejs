/*
 * RENDER THE DOCS
 */
exports.showDocs = function(req, res) {
	res.render('docs.ejs');
};
